package cs2321;

import net.datastructures.*;

public class HashMap<K, V> extends AbstractMap<K, V> implements Map<K, V> {
	// Instance Variables
	int capacity; // The size of the hash table
	int n = 0; // number of entries
	int prime; // prime factor

	// Constructor
	public HashMap(int cap, int p) {
		prime = p;
		capacity = cap;
		createTable();

	}

	private UnorderedMap<K, V>[] table;

	/**
	 * Constructor that takes a hash size
	 * 
	 * @param hashsize
	 *            Table capacity: the number of buckets to initialize in the
	 *            HashMap
	 */
	public HashMap(int hashsize) {
		this(hashsize, 109345121);
		capacity = hashsize;

	}

	// Default Constructor
	public HashMap() {
		this(17);
	}

	private int hashValue(K key) {
		return Math.abs(key.hashCode()) % capacity;
	}

	/*
	 * returns the size of the hashMap
	 * 
	 * @return the size of the hashMap
	 */
	@TimeComplexity("O(1")
	public int size() {
		return n;
	}

	/*
	 * checks to see if the hashMap is empty or not
	 * 
	 * @return true if size is less than or equal to zero, else false
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if (n <= 0)
			return true;
		return false;
	}

	/*
	 * finds the requested key in the hashMap
	 * 
	 * @return the requested key
	 */
	@TimeComplexity("O(1)")
	public V get(K key) {
		return bucketGet(hashValue(key), key);
	}

	/*
	 * puts the requested value into the key, resizing if needed
	 * 
	 * @return the old value of the key or null if there was none
	 */
	@TimeComplexity("O(1)")
	public V put(K key, V value) {
		V answer = bucketPut(hashValue(key), key, value);
		if (n > capacity / 2)
			resize(2 * capacity - 1);
		return answer;
	}

	/*
	 * removes the requested key
	 * 
	 * @return the key that was removed
	 */
	@TimeComplexity("O(1)")
	public V remove(K key) {
		return bucketRemove(hashValue(key), key);
	}

	/*
	 * creates an iterable entry set
	 * 
	 * @return the iterable buffer
	 */
	@TimeComplexity("O(n^2)")
	public Iterable<Entry<K, V>> entrySet() {
		ArrayList<Entry<K, V>> buffer = new ArrayList<>();
		for (int h = 0; h < capacity; h++)
			if (table[h] != null)
				for (Entry<K, V> entry : table[h].entrySet())
					buffer.add(buffer.size(), entry);
		return buffer;
	}

	/*
	 * resizes the hashMap
	 * 
	 */
	@TimeComplexity("O(n^2)")
	private void resize(int newCap) {
		ArrayList<Entry<K, V>> buffer = new ArrayList<>(n);
		for (Entry<K, V> e : entrySet())
			buffer.add(buffer.size(), e);
		capacity = newCap;
		createTable();
		n = 0;
		for (Entry<K, V> e : buffer)
			put(e.getKey(), e.getValue());

	}

	/*
	 * creates an empty table with length equaling the capacity
	 */
	@TimeComplexity("O(1)")
	protected void createTable() {
		table = (UnorderedMap<K, V>[]) new UnorderedMap[capacity]; // Safe cast
	}

	/*
	 * finds the requested key with the hash value h
	 * 
	 * @return the requested key, if doesn't exist return null
	 */
	@TimeComplexity("O(1)")
	protected V bucketGet(int h, K k) {
		UnorderedMap<K, V> bucket = table[h];
		if (bucket == null)
			return null;
		return bucket.get(k);
	}

	/*
	 * puts the key k "into" the bucket v with the value h
	 * 
	 * @return the old value
	 */
	@TimeComplexity("O(1)")
	protected V bucketPut(int h, K k, V v) {
		UnorderedMap<K, V> bucket = table[h];
		if (bucket == null)
			bucket = table[h] = new UnorderedMap<>();
		int oldSize = bucket.size();
		V answer = bucket.put(k, v);
		n += (bucket.size() - oldSize);
		return answer;
	}

	/*
	 * removes key k from bucket with hash value h
	 * 
	 * @return the removed bucket key
	 */
	@TimeComplexity("O(1)")
	protected V bucketRemove(int h, K k) {
		UnorderedMap<K, V> bucket = table[h];
		if (bucket == null)
			return null;
		int oldSize = bucket.size();
		V answer = bucket.remove(k);
		n -= (oldSize - bucket.size());
		return answer;

	}

}
