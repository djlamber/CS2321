package cs2321;

import net.datastructures.*;

/*
 * Implement Graph interface. A graph can be declared as either directed or undirected.
 * In the case of an undirected graph, methods outgoingEdges and incomingEdges return the same collection,
 * and outDegree and inDegree return the same value.
 * 
 * @author CS2321 Instructor
 */
public class AdjListGraph<V, E> implements Graph<V, E> {
	private boolean isdirected = false;
	private DoublyLinkedList<Vertex<V>> vertices = new DoublyLinkedList<>();
	private DoublyLinkedList<Edge<E>> edges = new DoublyLinkedList<>();

	//constructors
	public AdjListGraph(boolean directed) {
		isdirected = directed;
	}
	public AdjListGraph() {
	}

	/*
	 * gets the list of edges and returns it
	 * 
	 * @return an iterable list of edges
	 */
	@TimeComplexity("O(m)")
	public Iterable<Edge<E>> edges() {
		return edges;
	}

	/*
	 * validates the given edge and returns a reference to the requested array
	 * 
	 * @return the reference to the endpoint array
	 */
	@TimeComplexity("O(1)")
	public Vertex[] endVertices(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
		return edge.getEndpoints();
	}

	/*
	 * inserts a nonexisting edge into the graph
	 * 
	 * @return new edge
	 * @throw if the edge already exists
	 */
	@TimeComplexity("O(1)")
	public Edge<E> insertEdge(Vertex<V> u, Vertex<V> v, E o) throws IllegalArgumentException {
		if (getEdge(u, v) == null) {
			InnerEdge<E> e = new InnerEdge<>(u, v, o);
			e.setPosition(edges.addLast(e));
			InnerVertex<V> origin = validate(u);
			InnerVertex<V> dest = validate(v);
			origin.getOutgoing().put(v, e);
			dest.getIncoming().put(u, e);
			return e;
		} else
			throw new IllegalArgumentException("Edge from u to v exists");
	}

	/*
	 * inserts a new vertex
	 * 
	 * @return the new vertex
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> insertVertex(V o) {
		InnerVertex<V> v = new InnerVertex<>(o, isdirected);
		v.setPosition(vertices.addLast(v));
		return v;
	}

	/*
	 * gets the number of edges and returns it
	 * 
	 * @return the number of edges
	 */
	@TimeComplexity("O(1)")
	public int numEdges() {
		return edges.size();
	}

	/*
	 * gets the number of vertices and returns it
	 * 
	 * @return the number of vertices
	 */
	@TimeComplexity("O(1)")
	public int numVertices() {
		return vertices.size();
	}

	/*
	 * finds the opposite vertex of the given vertex and connecting edge
	 * 
	 * @return the endpoints of the found vertex
	 * @throws if the given vertex and edge are not connected
	 */
	@TimeComplexity("O(1)")
	public Vertex<V> opposite(Vertex<V> v, Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
		Vertex<V>[] endpoints = edge.getEndpoints();
		if (endpoints[0] == v)
			return endpoints[1];
		else if (endpoints[1] == v)
			return endpoints[0];
		else
			throw new IllegalArgumentException("v is not incident to this edge");
	}

	/*
	 * removes the requested edge from the graph
	 * 
	 * @throws if the given edge isn't a valid edge
	 */
	@TimeComplexity("O(1)")
	public void removeEdge(Edge<E> e) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
		InnerVertex<V>[] vers = (InnerVertex<V>[]) edge.getEndpoints();
		vers[0].getOutgoing().remove(vers[1]);
		vers[1].getIncoming().remove(vers[0]);
		edges.remove(edge.getPosition());
		edge.setPosition(null);
	}

	/*
	 * removes the requested vertex from the graph
	 * 
	 * @throws if the requested vertex isn't valid
	 */
	@TimeComplexity("O(deg(v))")
	public void removeVertex(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		for (Edge<E> e : vert.getOutgoing().values())
			removeEdge(e);
		for (Edge<E> e : vert.getIncoming().values())
			removeEdge(e);
		vertices.remove(vert.getPosition());
	}

	/*
	 * finds the given edge's element and replaces it with a new one
	 * 
	 * @return the old edge's element
	 * @throw if the original edge isn't valid
	 */
	@TimeComplexity("O(1)")
	public E replace(Edge<E> e, E o) throws IllegalArgumentException {
		InnerEdge<E> edge = validate(e);
		E old = edge.getElement();
		edge.element = o;
		return old;
	}

	/*
	 * finds the given vertex's element and replaces it with a new one
	 * 
	 * @return the old vertex's element
	 * @throw if the original vertex isn't valid
	 */
	@TimeComplexity("O(1)")
	public V replace(Vertex<V> v, V o) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		V old = vert.getElement();
		vert.element = o;
		return old;
	}

	/*
	 * returns an iterable list of the graph's vertices
	 * 
	 * @return the list of vertices
	 */
	@TimeComplexity("O(n)")
	public Iterable<Vertex<V>> vertices() {
		return vertices;
	}

	/*
	 * finds out the number of edges for vertex v is the origin
	 * 
	 * @return the number of edges v is the origin for
	 */
	@TimeComplexity("O(1)")
	public int outDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		return vert.getOutgoing().size();
	}

	/*
	 * finds out the number of edges for v is the destination
	 * 
	 * @return the number of edges v is the destination for
	 */
	@TimeComplexity("O(1)")
	public int inDegree(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		return vert.getIncoming().size();
	}

	/*
	 * gets an iterable list of valid outgoing edges
	 * 
	 * @return an iterable list of edges in which the vertex v is the origin
	 * @throw if the vertex is invalid
	 */
	@TimeComplexity("O(deg(v))")
	public Iterable<Edge<E>> outgoingEdges(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		return vert.getOutgoing().values();
	}

	/*
	 * gets an iterable list of valid incoming edges
	 * 
	 * @return an iterable list of edges in which the vertex v is the destination
	 * @throw if the vertex is invalid
	 */
	@TimeComplexity("O(deg(v))")
	public Iterable<Edge<E>> incomingEdges(Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> vert = validate(v);
		return vert.getIncoming().values();
	}

	/*
	 * finds and returns the requested valid edge
	 * 
	 * @return the requested edge
	 * @throws if the requested edge is invalid
	 */
	@TimeComplexity("O(min(deg(u),deg(v)))")
	public Edge<E> getEdge(Vertex<V> u, Vertex<V> v) throws IllegalArgumentException {
		InnerVertex<V> origin = validate(u);
		return origin.getOutgoing().get(v);
	}

	/*
	 * checks to see if the given vertex is valid
	 * 
	 * @return the validated vertex
	 * @throw if the vertex is invalid
	 */
	@TimeComplexity("O(1)")
	private InnerVertex<V> validate(Vertex<V> v) {
		if (!(v instanceof InnerVertex))
			throw new IllegalArgumentException("Invalid vertex");
		InnerVertex<V> ver = (InnerVertex<V>) v; // safe cast
		if (!ver.validate(this))
			throw new IllegalArgumentException("Invalid vertex");
		return ver;
	}

	/*
	 * checks to see if the given edge is valid
	 * 
	 * @return the validated edge
	 * @throw if the edge is invalid
	 */
	@TimeComplexity("O(1)")
	private InnerEdge<E> validate(Edge<E> e) {
		if (!(e instanceof InnerEdge))
			throw new IllegalArgumentException("Invalid edge");
		InnerEdge<E> edge = (InnerEdge<E>) e; // safe cast
		if (!edge.validate(this))
			throw new IllegalArgumentException("Invalid edge");
		return edge;
	}
//Inner Vertex Class
	private class InnerVertex<V> implements Vertex<V> {
		private V element;
		private Position<Vertex<V>> pos;
		private Map<Vertex<V>, Edge<E>> outgoing, incoming;

		// constructor
		public InnerVertex(V ele, boolean graphIsDirected) {
			element = ele;
			outgoing = new HashMap<>();
			if (graphIsDirected)
				incoming = new HashMap<>();
			else
				incoming = outgoing;
		}

		//getters and setters
		public V getElement() {
			return element;
		}
		public void setPosition(Position<Vertex<V>> p) {
			pos = p;
		}
		public Position<Vertex<V>> getPosition() {
			return pos;
		}
		public Map<Vertex<V>, Edge<E>> getOutgoing() {
			return outgoing;
		}
		public Map<Vertex<V>,Edge<E>> getIncoming() {
			return incoming;
		}
		public boolean validate(Graph<V, E> graph) {
			return AdjListGraph.this == graph && pos != null;
		}
	}
//Inner Edge class
	private class InnerEdge<E> implements Edge<E> {
		private E element;
		private Position<Edge<E>> pos;
		private Vertex<V>[] endpoints;

		public InnerEdge(Vertex<V> u, Vertex<V> v, E ele) {
			element = ele;
			endpoints = (Vertex<V>[]) new Vertex[] { u, v };
		}

		//getters and setters
		public E getElement() {
			return element;
		}
		public Vertex<V>[] getEndpoints() {
			return endpoints;
		}
		public void setPosition(Position<Edge<E>> p) {
			pos = p;
		}
		public Position<Edge<E>> getPosition() {
			return pos;
		}
		public boolean validate(Graph<V, E> graph) {
			return AdjListGraph.this == graph && pos != null;
		}
	}
}
