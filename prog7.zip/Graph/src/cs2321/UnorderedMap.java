package cs2321;

import java.util.Iterator;

import net.datastructures.Entry;

public class UnorderedMap<K, V> extends AbstractMap<K, V> {
	// Instance Variables
	private ArrayList<mapEntry<K, V>> map = new ArrayList<>();
	private int size = 0;

	// Default Constructor
	public UnorderedMap() {
	}

	/*
	 * finds and returns the size of the map
	 * 
	 * @return the size of the map
	 */
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	/*
	 * checks to see if the map is empty
	 * 
	 * @return false if the map size is greater than 0, else true
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if (size > 0)
			return false;
		return true;
	}

	/*
	 * finds and gets the requested key
	 * 
	 * @return the key asked for, if no key exists return null
	 */
	@TimeComplexity("O(n)")
	public V get(K key) {
		int j = findIndex(key);
		if (j == -1)
			return null;
		return map.get(j).getValue();
	}

	/*
	 * puts a key with a value into the map, if key already exits replace it
	 * 
	 * @return the previous key if there was one or null if there was no
	 * previous key
	 */
	@TimeComplexity("O(n)")
	public V put(K key, V value) {

		int j = findIndex(key);
		if (j == -1) {
			map.add(map.size(), new mapEntry<K, V>(key, value));
			return null;
		} else
			map.get(j).setValue(value);
		return map.get(j).getValue();
	}

	/*
	 * removes requested key from the map and returns its value
	 * 
	 * @return the value of the requested key, if no key was found returns null
	 */
	@TimeComplexity("O(n)")
	public V remove(K key) {
		int j = findIndex(key);
		int n = map.size();
		if (j == -1)
			return null;
		V answer = map.get(j).getValue();
		if (j != n - 1)
			map.set(j, map.get(n - 1));
		map.remove(n - 1);
		return answer;
	}

	/*
	 * finds the index of a specified key
	 * 
	 * @return the requested index of the key or -1 if it doesn't exist
	 */
	@TimeComplexity("O(n)")
	private int findIndex(K key) {
		int n = map.size();
		for (int j = 0; j < n; j++)
			if (map.get(j).getKey().equals(key))
				return j;
		return -1;
	}

	/*
	 * creates and returns a new entrySet
	 * 
	 * @return a new EntryIterable
	 */
	@TimeComplexity("O(XXXXX)")
	public Iterable<Entry<K, V>> entrySet() {
		return new EntryIterable();
	}

	// Class for EntryIterable
	private class EntryIterable implements Iterable<Entry<K, V>> {

		/*
		 * creates and returns new EntryIterator
		 * 
		 * @returns new EntryIterator
		 */
		@TimeComplexity("O(1)")
		public Iterator<Entry<K, V>> iterator() {
			return new EntryIterator();
		}
	}

	// Class for Entry Iterator
	private class EntryIterator implements Iterator<Entry<K, V>> {
		// instance variable
		private int j = 0;

		/*
		 * checks to see if j is less than the map size
		 * 
		 * @return true if j is less than size, else false
		 */
		@TimeComplexity("O(1)")
		public boolean hasNext() {
			return j < map.size();
		}

		/*
		 * finds the next entry in the iterator
		 * 
		 * @return if j!=0 the next entry, else null
		 */
		@TimeComplexity("O(1)")
		public Entry<K, V> next() {
			if (j == map.size())
				return null;
			return map.get(j++);
		}
	}
}
