/*
 * Daniel Lambert
 * Assignment 1
 * This class is used to create an ArrayList that grows in size once capacity is reached
 */
package cs2321;

import java.util.Iterator;

import net.datastructures.List;

public class ArrayList<E> implements List<E> {
	// Instance variables
	private int size = 0; // number of elements in list
	private static int Capacity = 1000; // default capacity
	private E[] data; // storage

	// Constructors
	public ArrayList() {
		this(Capacity);
	}

	public ArrayList(int capacity) {
		data = (E[]) new Object[capacity]; //safe cast
		Capacity = capacity;
	}
 
	/*
	 * gets the size of the arrayList and returns it
	 * 
	 * @return the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	/*
	 * Checks to see if the size of the ArrayList is 0
	 * 
	 * @return a boolean if the arrayList is empty or not
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if (size() == 0)
			return true;
		else
			return false;
	}

	/*
	 * Finds and returns the element at index i
	 * 
	 * @return the element at index i
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public E get(int i) throws IndexOutOfBoundsException {
		validIndex(i);
		return data[i];
	}

	/*
	 * Finds and replaces the element at index i with element e
	 * 
	 * @return the new element that was put in i
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public E set(int i, E e) throws IndexOutOfBoundsException {
		validIndex(i);
		if (this.get(i)==null)
			size++;
		E set = data[i];
		data[i] = e;
		return set;
	}

	/*
	 * Adds element e to the index i moving the following elements to the right
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(n)")
	public void add(int i, E e) throws IndexOutOfBoundsException {
		validIndex(i);
		for (int j = size - 1; j >= i; j--)
			data[j + 1] = data[j];
		data[i] = e;
		size++;
	}

	/*
	 * Removes the element from index i and shifting everything to the right of
	 * it left
	 * 
	 * @return returns the element that was removed from index i
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(n)")
	public E remove(int i) throws IndexOutOfBoundsException {
		validIndex(i);
		E remove = data[i];
		for (int j = i; j < size - 1; j++)
			data[j] = data[j + 1];
		data[size - 1] = null;
		size--;
		return remove;
	}

	// ArrayIterator Class
	private class ArrayIterator implements Iterator<E> {
		// Instance Variable
		private int i = 0; // index of next element

		/*
		 * Goes through the arrayList and sees if there is a next element
		 * 
		 * @return true if i is less than the size of the array. False otherwise
		 */
		@TimeComplexity("O(n)")
		public boolean hasNext() {
			return i < size;
		}

		/*
		 * Goes through the arrayList and returns the elements
		 * 
		 * @return data and increments i for the next iteration
		 */
		@TimeComplexity("O(1)")
		public E next() {
			if (i == size)
				return null;
			return data[i++];
		}

	}// End of ArrayIterator Class

	/*
	 * Iterates through the arrayList
	 * 
	 * @return a new ArrayIteration of the elements in the list
	 */
	@TimeComplexity("O(n)")
	public Iterator<E> iterator() {
		return new ArrayIterator();
	}

	/*
	 * Adds the element e to the beginning of the ArrayList
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(n)")
	public void addFirst(E e) throws IndexOutOfBoundsException {
		for (int j = size - 1; j >= 0; j--)
			data[j + 1] = data[j];
		data[0] = e;
		size++;

	}

	/*
	 * Adds the element e to the end of the ArrayList
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public void addLast(E e) throws IndexOutOfBoundsException {
		data[size] = e;
		size++;
	}

	/*
	 * removes the element at the beginning of the ArrayList
	 * 
	 * @return the first element in the list
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(n)")
	public E removeFirst() throws IndexOutOfBoundsException {
		E remove = data[0];
		for (int j = 0; j < size - 1; j++)
			data[j] = data[j + 1];
		data[size - 1] = null;
		size--;
		return remove;
	}

	/*
	 * removes the element at the end of the ArrayList
	 * 
	 * @return the last element in the list
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public E removeLast() throws IndexOutOfBoundsException {
		E remove = data[size - 1];
		data[size - 1] = null;
		size--;
		return remove;
	}

	/*
	 * Checks to see if the index is in range of the ArrayList
	 * 
	 * @throws IndexOutOfBoundsException if the index is negative or larger than
	 * the size of the arrayList
	 */
	@TimeComplexity("O(1)")
	public void validIndex(int i) throws IndexOutOfBoundsException {
		if (i < 0 || i >= size+1)
			throw new IndexOutOfBoundsException("Index Out Of Bounds at position " + i);

	}

	public static void main(String[] args) {
		ArrayList<String> Test = new ArrayList<>();
		Test.addFirst("Hello");
		Test.addLast("Goodbye");
		Test.add(1, "This should be at postion 1");
		Test.add(2, "This should be at position 2");
		Test.set(1, "I've replaced position 1!");
		Test.removeFirst();
		Test.remove(2);
		
	}

}
