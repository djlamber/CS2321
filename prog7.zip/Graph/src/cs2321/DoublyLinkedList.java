package cs2321;
/*
 * Daniel Lambert
 * Assignment 1
 * This class is used to create a DoublyLinkedList out of nodes with a head and tail node to mark each endpoint
 */


import java.util.Iterator;

import net.datastructures.Position;
import net.datastructures.PositionalList;

public class DoublyLinkedList<E> implements PositionalList<E> {
	// Node Class
	private static class Node<E> implements Position<E> {
		private E element; // element stored
		private Node<E> prev; // the previous node in the list
		private Node<E> next; // the next node in the list

		// Node constructor
		public Node(E element, Node<E> prev, Node<E> next) {
			this.element = element;
			this.setPrev(prev);
			this.next = next;
		}

		/*
		 * finds and returns the element from it's position
		 * 
		 * @return the found element
		 */
		@TimeComplexity("O(1)")
		public E getElement() throws IllegalStateException {
			if (next == null)
				throw new IllegalStateException("Position invalid");
			return element;
		}

		// getters and setters
		public Node<E> getPrev() {
			return prev;
		}

		public Node<E> getNext() {
			return next;
		}

		public void setElement(E element) {
			this.element = element;
		}

		public void setNext(Node<E> next) {
			this.next = next;
		}

		public void setPrev(Node<E> prev) {
			this.prev = prev;
		}
	}
	// end of node class

	// Instance variables
	private Node<E> head; // head of the doublyLinkedList
	private Node<E> tail; // end of the doublyLinkedList
	private int size = 0; // size of the doublyLinkedList

	// Constructor
	public DoublyLinkedList() {
		head = new Node<>(null, null, null); // creates head
		tail = new Node<>(null, head, null); // creates tail
		head.setNext(tail); // links head and tail
	}

	/*
	 * checks to see if the node is the head or tail nodes
	 * 
	 * @return the node or null if the node is the head or tail
	 */
	@TimeComplexity("O(1)")
	private Position<E> position(Node<E> node) {
		if (node == head || node == tail)
			return null;
		return node;
	}

	/*
	 * Checks to see if the size of the list is 0
	 * 
	 * @return a boolean if the list is empty or not
	 */
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	/*
	 * Checks to see if the size of the list is 0
	 * 
	 * @return a boolean if the list is empty or not
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	/*
	 * Finds and returns the position of the first element in the list
	 *
	 * @return the position of the node after the head. If the list is empty
	 * returns null.
	 */
	@TimeComplexity("O(1)")
	public Position<E> first() {
		if (isEmpty())
			return null;
		return position(head.getNext());
	}

	/*
	 * Finds and returns the position of the last element in the list
	 *
	 * @return the position of the node after the tail. If the list is empty
	 * returns null.
	 */
	@TimeComplexity("O(1)")
	public Position<E> last() {
		if (isEmpty())
			return null;
		return position(tail.getPrev());
	}

	/*
	 * Takes in a legal positions and returns the position before it
	 * 
	 * @return the position before the given position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public Position<E> before(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		return position(node.getPrev());
	}

	/*
	 * Takes in a legal positions and returns the position after it
	 * 
	 * @return the position after the given position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public Position<E> after(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		return position(node.getNext());
	}

	/*
	 * Adds the element into the first position
	 * 
	 * @return the new position of the new node after head
	 */
	@TimeComplexity("O(1)")
	public Position<E> addFirst(E e) {
		return addBetween(e, head, head.getNext());
	}

	/*
	 * Adds the element into the last position
	 * 
	 * @return the new position of the new node before tail
	 */
	@TimeComplexity("O(1)")
	public Position<E> addLast(E e) {
		return addBetween(e, tail.getPrev(), tail);
	}

	/*
	 * Adds the element into the position before the given valid position
	 * 
	 * @return the position of the new node before the specified position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public Position<E> addBefore(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = check(p);
		return addBetween(e, node.getPrev(), node);
	}

	/*
	 * Adds the element into the position after the given valid position
	 * 
	 * @return the position of the new node after the specified position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public Position<E> addAfter(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = check(p);
		return addBetween(e, node, node.getNext());
	}

	/*
	 * Takes an existing position and gives it a new element
	 * 
	 * @returns the new contents of the position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public E set(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = check(p);
		E element = node.getElement();
		node.setElement(e);
		return element;
	}

	/*
	 * Takes an existing position and removes it linking it's 'neighbors'
	 * together and returning the element it stored
	 * 
	 * @returns the element stored in the old position
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public E remove(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		Node<E> prev = node.getPrev();
		Node<E> next = node.getNext();
		prev.setNext(next);
		next.setPrev(prev);
		size--;
		E result = node.getElement();
		node.setElement(null);
		node.setNext(null);
		node.setPrev(null);
		return result;
	}

	// PositionIterator Class
	private class PositionIterator implements Iterator<Position<E>> {
		// Instance variables
		private Position<E> cursor = first(); // Position in the list
		private Position<E> recent = null; // last position in the list

		/*
		 * Checks to see if there is another element in the list
		 * 
		 * @returns a boolean if the cursor is equal to null return false,
		 * otherwise return true
		 * 
		 */
		@TimeComplexity("O(1)")
		public boolean hasNext() {
			return (cursor != null);
		}

		/*
		 * iterates through to the next position changing the cursor and recent
		 * 
		 * @returns the next position
		 */
		@TimeComplexity("O(1)")
		public Position<E> next() {
			if (cursor == null)
				return null;
			recent = cursor;
			cursor = after(cursor);
			return recent;
		}

	}// End of PositionIterator Class

	// PositionIterable Class
	private class PositionIterable implements Iterable<Position<E>> {

		/*
		 * Creates a new PositionIteror
		 * 
		 * @returns an new PositionIterator
		 */
		@TimeComplexity("O(1)")
		public Iterator<Position<E>> iterator() {
			return new PositionIterator();
		}

	}// End of PositionIterable Class

	// ElementIterator Class
	private class ElementIterator implements Iterator<E> {
		Iterator<Position<E>> posIterator = new PositionIterator();

		/*
		 * Checks to see if there is another element in the list
		 * 
		 * @returns a boolean if the cursor is equal to null return false,
		 * otherwise return true
		 * 
		 */
		@TimeComplexity("O(1)")
		public boolean hasNext() {
			return posIterator.hasNext();
		}

		/*
		 * iterates through to the next element
		 * 
		 * @returns the next element
		 */
		@TimeComplexity("O(1)")
		public E next() {
			return posIterator.next().getElement();
		}

	}

	/*
	 * Creates a new Element Iterator
	 *
	 * @returns a new Element Iterator
	 */
	@TimeComplexity("O(1)")
	public Iterator<E> iterator() {
		return new ElementIterator();
	}

	/*
	 * Creates a new PositionIterable
	 * 
	 * @returns an iterable list of the positions
	 */
	@TimeComplexity("O(1)")
	public Iterable<Position<E>> positions() {
		return new PositionIterable();
	}

	/*
	 * Removes the first node in the list
	 * 
	 * @return the element of the removed node. If the list is empty returns
	 * null
	 *
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public E removeFirst() throws IllegalArgumentException {
		if (isEmpty())
			return null;
		return remove(head.next);
	}

	/*
	 * Removes the last node in the list
	 * 
	 * @return the element of the removed node. If the list is empty returns
	 * null
	 *
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	public E removeLast() throws IllegalArgumentException {
		if (isEmpty())
			return null;
		return remove(tail.prev);
	}

	/*
	 * Checks to see if the Node's position is valid
	 * 
	 * @return the node if the position is valid
	 * 
	 * @throws IlleagalArgumentException if the position is invalid
	 */
	@TimeComplexity("O(1)")
	private Node<E> check(Position<E> p) throws IllegalArgumentException {
		if (!(p instanceof Node))
			throw new IllegalArgumentException("Invalid Position");
		Node<E> node = (Node<E>) p;
		if (node.getNext() == null)
			throw new IllegalArgumentException("Posititon is no longer in the list");
		return node;
	}

	/*
	 * Adds a new Positional Node between two existing nodes
	 * 
	 * @return the new node created
	 */
	@TimeComplexity("O(1)")
	private Position<E> addBetween(E e, Node<E> prev, Node<E> next) {
		Node<E> newer = new Node<>(e, prev, next);
		prev.setNext(newer);
		next.setPrev(newer);
		size++;
		return newer;

	}

	public static void main(String[] args) {
		DoublyLinkedList<String> test = new DoublyLinkedList<>();
		test.addFirst("hello");
	}
}
