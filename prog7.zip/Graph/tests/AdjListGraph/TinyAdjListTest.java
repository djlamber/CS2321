import org.junit.*;
import jug.*;
import cs2321.*;
import net.datastructures.*;

@jug.SuiteName("TinyAdjListTest")
public class TinyAdjListTest {

	private AdjListGraph TARGET = init();
	private AdjListGraph T = init();

	public AdjListGraph init() {
		return new AdjListGraph();
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying numVertices() equals 2")
	public void Test1() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )( new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" ) );
		
		org.junit.Assert.assertEquals("Verifying numVertices() equals 2", (Object)(2), (Object)(TARGET.numVertices()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying numEdges() equals 1")
	public void Test2() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		
		org.junit.Assert.assertEquals("Verifying numEdges() equals 1", (Object)(1), (Object)(TARGET.numEdges()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying getEdge((0,0), (1,0)) equals not null")
	public void Test3() throws Throwable {
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 0, 0 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 1, 0 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		TARGET.insertEdge( v1, v2, lWalkway );
		
		org.junit.Assert.assertEquals("Verifying getEdge((0,0), (1,0)) equals not null", (Object)(false), (Object)(TARGET.getEdge(v2, v1)==null));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying getEdge((1,0), (0,0)) equals not null")
	public void Test4() throws Throwable {
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 0, 0 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 1, 0 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		TARGET.insertEdge( v1, v2, lWalkway );
		
		org.junit.Assert.assertEquals("Verifying getEdge((1,0), (0,0)) equals not null", (Object)(false), (Object)(TARGET.getEdge(v2, v1)==null));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying endVertices({(0, 0), (1, 0)}) equals (0, 0), (1, 0)")
	public void Test5() throws Throwable {
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 0, 0 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 1, 0 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> lEdge = TARGET.insertEdge( v1, v2, lWalkway );
		Vertex[] vertices = TARGET.endVertices( lEdge );
		Vertex [] values = {v1, v2}
		;
		boolean [] checked = new boolean[values.length];
		for(Vertex v : vertices) {
				for(int j=0; j<values.length; j++) {
					if(values[j].equals(v)) {
						checked[j]=true;
					}
				}
			}
		for(int j=0; j<checked.length; j++)//;
		
		org.junit.Assert.assertEquals("Verifying endVertices({(0, 0), (1, 0)}) equals (0, 0), (1, 0)", (Object)(true), (Object)(checked[j]));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying insertVertex((1,1)), numVertices() equals 3")
	public void Test6() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		
		org.junit.Assert.assertEquals("Verifying insertVertex((1,1)), numVertices() equals 3", (Object)(3), (Object)(TARGET.numVertices()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying v = insertVertex((1,1)), v.getElement().toString() equals \"(1, 1)\"")
	public void Test7() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		Vertex<RoomCoordinate> v = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		
		org.junit.Assert.assertEquals("Verifying v = insertVertex((1,1)), v.getElement().toString() equals \"(1, 1)\"", (Object)("(1,1)"), (Object)(v.getElement().toString()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying insertEdge((1,1),(0,1)), numEdges() equals 2")
	public void Test8() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		
		org.junit.Assert.assertEquals("Verifying insertEdge((1,1),(0,1)), numEdges() equals 2", (Object)(2), (Object)(TARGET.numEdges()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying insertEdge(( 1, 1 ), ( 0, 1 ), (1,1)(0,1)); getEdge((1, 1), (0, 1)) equals not null")
	public void Test9() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		
		org.junit.Assert.assertEquals("Verifying insertEdge(( 1, 1 ), ( 0, 1 ), (1,1)(0,1)); getEdge((1, 1), (0, 1)) equals not null", (Object)(false), (Object)(TARGET.getEdge( v1, v2 )==null));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying e = insertEdge(( 1, 1 ), ( 0, 1 ), (1,1)(0,1)), e.getElement().getName() equals (1, 1)(0, 1)")
	public void Test10() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		
		org.junit.Assert.assertEquals("Verifying e = insertEdge(( 1, 1 ), ( 0, 1 ), (1,1)(0,1)), e.getElement().getName() equals (1, 1)(0, 1)", (Object)("(1,1)(0,1)"), (Object)(e.getElement().getName()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying outgoingEdges(( 1, 1 )) size equals 1")
	public void Test11() throws Throwable {
		int size = 0;
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		Iterable<Edge<Walkway>> edges = TARGET.outgoingEdges(v1);
		for(Edge edge : edges)
				size++;
		
		org.junit.Assert.assertEquals("Verifying outgoingEdges(( 1, 1 )) size equals 1", (Object)(1), (Object)(size));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying edges() size equals 1")
	public void Test12() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		int size = 0;
		Iterable<Edge<Walkway>> edges = TARGET.edges();
		for(Edge e : edges)
				size++;
		
		org.junit.Assert.assertEquals("Verifying edges() size equals 1", (Object)(1), (Object)(size));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying vertices() size equals 2")
	public void Test13() throws Throwable {
		TARGET = ( AdjListGraph<RoomCoordinate, Walkway> )new Labyrinth( "TinyLabyrinth.txt" ).setupLabyrinth( "TinyLabyrinth.txt" );
		int size = 0;
		Iterable<Vertex<RoomCoordinate>> vertices = TARGET.vertices();
		for(Vertex v : vertices)
				size++;
		
		org.junit.Assert.assertEquals("Verifying vertices() size equals 2", (Object)(2), (Object)(size));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying that removing edge (0,0)(1,0) makes those vertices not adjacent")
	public void Test14() throws Throwable {
		int size = 0;
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		TARGET.removeEdge( e );
		
		org.junit.Assert.assertEquals("Verifying that removing edge (0,0)(1,0) makes those vertices not adjacent", (Object)(null), (Object)(TARGET.getEdge( v1, v2 )));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying that removing edge (0,0)(1,0) returns the proper getElement")
	public void Test15() throws Throwable {
		int size = 0;
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		TARGET.removeEdge( e );
		
		org.junit.Assert.assertEquals("Verifying that removing edge (0,0)(1,0) returns the proper getElement", (Object)(0), (Object)(TARGET.numEdges()));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying that removing vertex (0,1) returns the proper getElement")
	public void Test16() throws Throwable {
		int size = 0;
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		TARGET.removeVertex( v2 );
		
		org.junit.Assert.assertEquals("Verifying that removing vertex (0,1) returns the proper getElement", (Object)(0), (Object)(TARGET.outDegree(v1)));
	}

	@org.junit.Test(timeout=15000)
	@jug.TestName("Verifying that removing vertex (0,1) removes the incident edge")
	public void Test17() throws Throwable {
		int size = 0;
		Vertex<RoomCoordinate> v1 = TARGET.insertVertex( new RoomCoordinate( 1, 1 ) );
		Vertex<RoomCoordinate> v2 = TARGET.insertVertex( new RoomCoordinate( 0, 1 ) );
		Walkway lWalkway = new Walkway( v1.getElement().toString() + v2.getElement().toString(), 1 );
		Edge<Walkway> e = TARGET.insertEdge( v1, v2, lWalkway );
		TARGET.removeVertex( v2 );
		
		org.junit.Assert.assertEquals("Verifying that removing vertex (0,1) removes the incident edge", (Object)(0), (Object)(TARGET.numEdges()));
	}

}
