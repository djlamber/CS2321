package cs2321.sorting;

public class InPlaceSelectionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place selection sort
	 * 
	 * @param array
	 *            - Array to sort
	 */

	public void sort(K[] array) {
		inPlaceSelectionSort(array);
	}

	public static <K extends Comparable<K>> void inPlaceSelectionSort(K[] A) {
		int n = A.length;
		for (int i = 0; i < n - 1; i++) {
			for (int j = i + 1; j < n; j++) {
				if (A[j].compareTo(A[i]) < 0) {
					K temp = A[j];
					A[j] = A[i];
					A[i] = temp;
				}
			}
		}
	}
}
