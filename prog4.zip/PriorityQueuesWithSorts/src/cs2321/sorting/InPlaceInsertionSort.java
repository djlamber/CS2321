package cs2321.sorting;

public class InPlaceInsertionSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place insertion sort
	 * @param array - Array to sort
	 */
	
	public void sort(K[] array) {
		inPlaceInsertionSort(array);
	}
	public static <K  extends Comparable<K>> void inPlaceInsertionSort(K[] A){
		int n = A.length;
		for(int k=1;k<n;k++){
			K curr = A[k];
			int j = k;
			while (j>0 && A[j-1].compareTo(curr)>0){
				A[j] = A[j-1];
				j--;
			}
			A[j] = curr;
		}
	}
}
