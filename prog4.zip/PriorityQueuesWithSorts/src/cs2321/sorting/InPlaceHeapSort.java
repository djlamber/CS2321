package cs2321.sorting;

public class InPlaceHeapSort<K extends Comparable<K>> implements Sorter<K> {

	/**
	 * sort - Perform an in-place heap sort
	 * @param array - Array to sort
	 */
	
	public void sort(K[] array) {
		heapSort(array);
	}
	private static int N;
	
	public static <K extends Comparable<K>> void heapSort(K[] A){
		
		heapify(A);
		for(int i = N;i>0;i-- ){
			swap(A,0,i);
			N=N-1;
			maxheap(A,0);
		}
	}
	
	public static <K extends Comparable<K>> void heapify(K[] A){
		N = A.length-1;
		for(int i=N/2; i>=0;i--)
			maxheap(A,i);
	}
	public static <K extends Comparable<K>> void maxheap(K[] A, int i){
		int left = 2*i;
		int right =2*i+1;
		int max = i;
		if (left <= N && A[left].compareTo(A[i])>0)
            max = left;
        if (right <= N && A[right].compareTo(A[max])>0)        
            max = right;
 
        if (max != i)
        {
            swap(A, i, max);
            maxheap(A, max);
        }
    }    
	public static <K extends Comparable<K>> void swap(K[] A, int i,int j){
		K tmp = A[i];
		A[i] = A[j];
		A[j] = tmp;
	
	}

}
