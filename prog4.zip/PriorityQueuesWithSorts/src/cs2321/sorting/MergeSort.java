package cs2321.sorting;

import java.util.Arrays;

public class MergeSort<E extends Comparable<E>> implements Sorter<E> {

	public void sort(E[] array) {
		mergeSort(array);
	}
	public static <K extends Comparable<K>> void merge(K[] S1, K[] S2, K[]S){
		int i = 0;
		int j = 0;
		while(i+j <S.length){
			if(j==S2.length || (i<S1.length && S1[i].compareTo(S2[j]) < 0))
					S[i+j] = S1[i++];
			else
				S[i+j] = S2[j++];
		}
	}
	public static <K extends Comparable<K>> void mergeSort(K[] S){
		int n = S.length;
		if(n<2) 
			return;
		//split the array in half
		int mid = n/2;
		K[] S1 = Arrays.copyOfRange(S, 0, mid);
		K[] S2 = Arrays.copyOfRange(S, mid, n);
		mergeSort(S1);
		mergeSort(S2);
		merge(S1,S2,S);
	}
}

