package cs2321.sorting;

public class QuickSort<E extends Comparable<E>> implements Sorter<E> {

	public void sort(E[] array) {
		quickSort(array,0,array.length-1);
	}

	public static <K extends Comparable<K>> void quickSort(K[] S, int l, int h) {
		if (l < h) {
			int i=l;
			int j=h;
			K x = S[(i+j)/2];
			do{
				while(S[i].compareTo(x)<0)
					i++;
				while(x.compareTo(S[j])<0)
					j--;
				
				if(i<=j){
					K tmp = S[i];
					S[i] = S[j];
					S[j] = tmp;
					i++;
					j--;
				}
			}while(i<=j);
			
			quickSort(S,l,j);
			quickSort(S,i,h);
		}
	}
}
