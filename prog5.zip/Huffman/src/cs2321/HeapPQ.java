package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A Adaptable PriorityQueue based on an heap. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Daniel Lambert
 */

public class HeapPQ<K,V> extends AbstractPriorityQueue<K,V> implements AdaptablePriorityQueue<K,V> {
	protected ArrayList<Entry<K,V>> heap = new ArrayList<>();	//Primary entry collection
	
	//Constructors
	public HeapPQ() {	//Creates an empty PQ based on original key ordering
		super();
	}
	public HeapPQ(Comparator<K> c) {	//Creates an empty PQ using the given comparator to order keys
		super(c);
	}
	//protected utilities
	
	/*
	 * Returns the parent index
	 * 
	 * @return the index of the parent
	 */
	@TimeComplexity("O(1)")
	protected int parent(int p){ 
		return (p-1)/2;
	}
	/*
	 * Returns the left child index
	 * 
	 * @return the index of the left child
	 */
	@TimeComplexity("O(1)")
	protected int left(int l){
		return 2*l+1;
	}
	/*
	 * Returns the right child index
	 * 
	 * @return the index of the right child
	 */
	@TimeComplexity("O(1)")
	protected int right(int r){
		return 2*r+2;
	}
	/*
	 * Returns if the index has a left child
	 * 
	 * @return true if the index has a left child, if else false
	 */
	@TimeComplexity("O(1)")
	protected boolean hasLeft(int l){
		return left(l) <heap.size();
	}
	/*
	 * Returns if the index has a right child
	 * 
	 * @return true if the index has a right child, if else false
	 */
	@TimeComplexity("O(1)")
	protected boolean hasRigth(int r){
		return right(r)<heap.size();
	}
	/*
	 * Swaps the elements of two indexes
	 */
	@TimeComplexity("O(1)")
	protected void swap(int i, int j){	//Swaps entries at i and j
		Entry<K,V> temp = heap.get(i);
		heap.set(i, heap.get(j));
		heap.set(j, temp);
	}
	/**
	 * The entry should be bubbled up to its appropriate position 
	 * @param int move the entry at index j higher if necessary, to restore the heap property
	 */ 
	/*
	 * upheaps the heap to restore heap order
	 */
	@TimeComplexity("O(log n)")
	public void upheap(int j){
		//TODO: implement this method
		while(j>0){
			int p = parent(j);
			if(compare(heap.get(j),heap.get(p))>=0)
					break;
			swap(j,p);
			j = p;
		}
	}
	
	/**
	 * The entry should be bubbled down to its appropriate position 
	 * @param int move the entry at index j lower if necessary, to restore the heap property
	 */
	/*
	 * downheaps the heap to restore heap order
	 */
	@TimeComplexity("O(log n)")
	public void downheap(int j){
		while (hasLeft(j)){
			int leftIndex = left(j);
			int smallerChildIndex = leftIndex;
			if (hasRigth(j)){
				int rightIndex = right(j);
				if (compare(heap.get(leftIndex), heap.get(rightIndex))>0)
					smallerChildIndex = rightIndex;
			}
			if (compare(heap.get(smallerChildIndex), heap.get(j))>=0)
				break;
			swap(j,smallerChildIndex);
			j=smallerChildIndex;
		}
	}

	/*
	 * Returns the size of the queue
	 * 
	 * @return the size of the queue
	 */
	@TimeComplexity("O(1)")
	public int size() {	//Returns size of queue
		return heap.size();
	}

	/*
	 * Returns if the queue is empty
	 * 
	 * @return true if the queue is empty, else false
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {	//Returns if the queue is empty or full
		if (heap.size() == 0)
			return true;
		else
			return false;
	}

	
	/*
	 * Inserts a new entry into the heap and restores order
	 * 
	 * @return the new entry into the heap
	 */
	@TimeComplexity("O(log n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);
		Entry<K,V> newest = new PQEntry<>(key,value);
		heap.add(heap.size(), newest);
		upheap(heap.size()-1);
		return newest;
	}

	/*
	 * Returns the minimum entry in the heap
	 * 
	 * @return the minimum entry
	 */
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {
		if(heap.isEmpty())
			return null;
		return heap.get(0);
	}

	/*
	 * Removes the minimum entry
	 * 
	 * @return the removed minimum entry
	 */
	@TimeComplexity("O(log n)")
	public Entry<K, V> removeMin() {
		if(heap.isEmpty())
			return null;
		Entry<K,V> answer = heap.get(0);
		swap(0,heap.size()-1);
		heap.remove(heap.size()-1);
		downheap(0);
		return answer;
	}
	
	//AdaptablePQEntry Class
	protected static class AdaptablePQEntry<K,V> extends PQEntry{
		private int index;
		//Constructor
		public AdaptablePQEntry(K key,V value, int j){
			super(key, value);
			index = j;
		}
		/*
		 * Gets and returns the index of the element
		 * 
		 * @return the index of the element
		 */
		@TimeComplexity("O(1)")
		public int getIndex(){
			return index;
		}
		/*
		 * Sets the index of the element
		 */
		@TimeComplexity("O(1)")
		public void setIndex(int j){
			index = j;
		}
		
	}
	
	/*
	 * Removes the entry specified and restores heap order
	 * 
	 * @throws IllegalArgumentException if the entry isn't valid
	 */
	@TimeComplexity("O(log n)")
	public void remove(Entry<K, V> entry) throws IllegalArgumentException {
		AdaptablePQEntry<K,V> locator = validate(entry);
		int j = locator.getIndex();
		if(j == heap.size()-1)
			heap.remove(heap.size()-1);
		else{
			swap(j,heap.size()-1);
			heap.remove(heap.size()-1);
			bubble(j);
		}
	}

	/*
	 * Replaces a key with a specified other key
	 * 
	 * @throws IllegalArgumentException if the entry isn't valid
	 */
	@TimeComplexity("O(log n)")
	public void replaceKey(Entry<K, V> entry, K key) throws IllegalArgumentException {
		AdaptablePQEntry<K,V> locator = validate(entry);
		checkKey(key);
		locator.setKey(key);
		bubble(locator.getIndex());
	}

	/*
	 * Replaces a value with a specified other value
	 * 
	 * @throws IllegalArgumentException if the entry isn't valid
	 */
	@TimeComplexity("O(1)")
	public void replaceValue(Entry<K, V> entry, V value) throws IllegalArgumentException {
		AdaptablePQEntry<K,V> locator = validate(entry);
		locator.setValue(value);
	}
	
	/*
	 * Bubbles up or down to restore heap order
	 */
	@TimeComplexity("O(1)")
	protected void bubble(int j){
		if(j>0 && compare(heap.get(j),heap.get(parent(j)))<0)
			upheap(j);
		else
			downheap(j);
	}
	
	/*
	 * Validates the entry 
	 * 
	 * @throws IllegalArgumentException if the entry isn't valid
	 * 
	 * @return the valid entry
	 */
	@TimeComplexity("O(1)")
	protected AdaptablePQEntry<K,V> validate(Entry<K,V> entry) throws IllegalArgumentException{
		if(!(entry instanceof AdaptablePQEntry))
			throw new IllegalArgumentException("Invalid Entry");
		AdaptablePQEntry<K,V> locator = (AdaptablePQEntry<K,V>) entry;
		int j = locator.getIndex();
		if(j>= heap.size()|| heap.get(j)!= locator)
			throw new IllegalArgumentException("Invalid Entry");
		return locator;
	}
}
