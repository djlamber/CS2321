package cs2321;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.file.Files;
import java.nio.file.Paths;

import net.datastructures.*;

/*
 * Encoding prefix tree bit stream: 
 * if the node is external, output 1, followed by the letter
 * if the node is internal, output 0, followed by 
 *  		the bit stream of left subtree, then the bit stream of right subtree. 
 */
public class Huffman {
	String toFile = "";
	String coded = "";

	/**
	 * 
	 * Compress file using Huffman code. For easy implementation, we represent
	 * bit 0 with '0', and bit 1 as '1' in the output.
	 *
	 * @param inputFile
	 *            The original data file
	 * @param outputFile
	 *            The compressed data file.
	 * @return
	 */
	public int compress(String inputFile, String outputFile) {
		ArrayList<Character> text = new ArrayList<Character>();
		try {
			FileReader in = new FileReader(inputFile);
			int length = 0;
			int i;
			while ((i = in.read()) != -1) {
				text.set(length, (char) i);
				length++;
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		ArrayList<Integer> CharAmount = new ArrayList<Integer>();
		for (int i = 0; i < 255; i++) {
			CharAmount.set(i, 0);
		}
		for (int i = 0; i < text.size(); i++) {
			if (text.get(i) == null)
				break;
			int w = text.get(i).charValue();
			CharAmount.set(w, CharAmount.get(w) + 1);
		}

		HeapPQ<Integer, Character> Order = new HeapPQ<>();
		int j = 0;
		for (int i = 0; i < CharAmount.size() - 1; i++) {
			if (CharAmount.get(i) > 0) {
				Order.insert(CharAmount.get(i), (char) i);
				if (Order.size() > 0)
					Order.upheap(j);
				j++;
			}
		}
		HeapPQ<Integer, LinkedBinaryTree<Character>> Forest = new HeapPQ<>();
		while (!Order.isEmpty()) {
			Entry<Integer, Character> e = Order.removeMin();
			LinkedBinaryTree<Character> t = new LinkedBinaryTree<>();
			t.addRoot(e.getValue());
			Forest.insert(e.getKey(), t);
		}

		while (Forest.size() > 1) {
			Entry<Integer, LinkedBinaryTree<Character>> t1 = Forest.removeMin();
			Entry<Integer, LinkedBinaryTree<Character>> t2 = Forest.removeMin();
			LinkedBinaryTree<Character> t3 = new LinkedBinaryTree<>();
			t3.addRoot(null);
			t3.attach(t3.root(), t1.getValue(), t2.getValue());
			Forest.insert(t1.getKey() + t2.getKey(), t3);
		}
		Entry<Integer, LinkedBinaryTree<Character>> tree = Forest.removeMin();
		LinkedBinaryTree<Character> BinaryTree = tree.getValue();
		TreeToFile(BinaryTree, BinaryTree.root, "");
		ArrayList<String> textHuffBi = new ArrayList<>();
		for (int i = 0; i < text.size(); i++) {
			treeEncode(BinaryTree, BinaryTree.root, text.get(i), "");
			textHuffBi.add(i, coded);
		}

		try {
			FileWriter out = new FileWriter(outputFile);
			out.write(toFile);
			for (int i = 0; i < textHuffBi.size(); i++) {
				out.write(textHuffBi.get(i));
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		int fs = 0;
		for (int i = 0; i < textHuffBi.size(); i++) {
			fs += textHuffBi.get(i).length();
		}

		return fs;
	}

	public void TreeToFile(LinkedBinaryTree<Character> bt, Position<Character> p, String code) {
		if (bt.isExternal(p)) {
			toFile = toFile + code + toBinary(p.getElement());

		}
		if (bt.right(p) != null)
			TreeToFile(bt, bt.right(p), code + 0);
		if (bt.left(p) != null)
			TreeToFile(bt, bt.left(p), code + 1);

	}

	public String toBinary(char b) {
		String binary = "";
		int val = b;
		for (int i = 0; i < 8; i++) {
			binary += ((val & 128) == 0 ? 0 : 1);
			val <<= 1;
		}
		return binary;
	}

	public void treeEncode(LinkedBinaryTree<Character> bt, Position<Character> p, char c, String HuffBi) {
		if (bt.isExternal(p)) {
			if (c == p.getElement())
				coded = HuffBi;

		}
		if (bt.right(p) != null)
			treeEncode(bt, bt.right(p), c, HuffBi + 0);
		if (bt.left(p) != null)
			treeEncode(bt, bt.left(p), c, HuffBi + 1);

	}

	/**
	 * Decode the compressed data file back to the original data file. For easy
	 * implementation, the bit 0 is '0' and the bit 1 is '1' in the compressed
	 * data.
	 * 
	 * @param inputFile
	 * @param outputFile
	 */
	public void decode(String inputFile, String outputFile) {
		ArrayList<Character> text = new ArrayList<Character>();
		try {
			FileReader in = new FileReader(inputFile);
			int length = 0;
			int i;
			while ((i = in.read()) != -1) {
				text.set(length, (char) i);
				length++;
			}
			in.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		readPrefixTree(text);
	}
	int readi = 0;
	public LinkedBinaryTree<Character> readPrefixTree(ArrayList<Character> text) {
		char y = text.get(readi);
		readi++;
		if (y == 1) {
			String num = "";
			for (int j = 0; j < 8; j++) {
				num += text.get(readi);
				readi++;
			}
			LinkedBinaryTree<Character> t = new LinkedBinaryTree<Character>();
			t.addRoot(BiToChar(num));
		} else if (y == 0) {
			LinkedBinaryTree<Character> t1 = readPrefixTree(text);
			LinkedBinaryTree<Character> t2 = readPrefixTree(text);
			LinkedBinaryTree<Character> t = new LinkedBinaryTree<Character>();
			t.addRoot(null);
			t.attach(t.root(), t1, t2);
			return t;
		}
		return null;

	}

	public char BiToChar(String s) {
		char c = 0;
		String b = "";
		for (int j = 0; j < 8; j++) {
			if (s.substring(j * 2, j * 2 + 1) == "49") {
				b += 1;
			} else if (s.substring(j * 2, j * 2 + 1) == "48") {
				b += 0;
			} else {
				return (Character) null;
			}
		}
		String str = "";
		for (int i = 0; i < b.length() / 8; i++) {

			int a = Integer.parseInt(s.substring(8 * i, (i + 1) * 8), 2);
			str += (char) (a);
		}

		return c;
	}

	public static void main(String[] args) {
		Huffman huffman = new Huffman();
		String[] inputData = { "ab.txt", "abra.txt", "tinytinyTale.txt", "medTale.txt", "tale.txt" };
		int[] length = { 5, 28, 128, 23599, 3043613 };

		for (int i = 0; i < inputData.length; i++) {
			System.out.println("processing " + inputData[i]);
			int l = huffman.compress(inputData[i], inputData[i] + ".compressed.new");
			System.out.println(" file " + inputData[i] + " length is " + l);
			if (length[i] != l) {
				System.out.println("wrong length");
			} else {
				System.out.println("correct length");
			}
			;

			huffman.decode(inputData[i] + ".compressed", inputData[i] + ".original");

		}

	}

}
