package cs2321;

import java.util.Comparator;

import net.datastructures.*;

public abstract class AbstractPriorityQueue<K,V> implements PriorityQueue<K,V> {

	protected static class PQEntry<K,V> implements Entry<K,V>{
		//
		private K k;	//key
		private V v;	//value
		public PQEntry(K key, V value){
			k = key;
			v = value;
		}
		/*
		 * Finds and returns the key of an Entry
		 * 
		 * @return the key of the Entry
		 */
		@TimeComplexity("O(1)")
		public K getKey() {
			return k;
		}

		/*
		 * Finds and returns the value of an Entry
		 * 
		 * @return the value of the Entry
		 */
		@TimeComplexity("O(1)")
		public V getValue() {
			return v;
		}
		
		/*
		 * Sets the key of an Entry
		 */
		@TimeComplexity("O(1)")
		public void setKey(K key){
			k=key;
		}
		/*
		 * Sets the value of an Entry
		 */
		@TimeComplexity("O(1)")
		public void setValue(V value){
			v=value;
		}
	}
	private Comparator<K> comp;	//Comparator for class
	
	//Constructors
	protected AbstractPriorityQueue(Comparator<K> c){
		comp = c;
	}
	protected AbstractPriorityQueue(){
		this(new DefaultComparator<K>());
	}
	
	/*
	 * Compares two entries to see how their keys compare
	 * 
	 * @returns the comparison of the two entries
	 */
	@TimeComplexity("O(1)")
	protected int compare(Entry<K,V> a, Entry<K,V> b){
		return comp.compare(a.getKey(), b.getKey());
	}
	
	/*
	 * Checks to see if the key is valid
	 * 
	 * @return if the key is valid
	 * 
	 * @throws IllegalArgumentException if the key isn't valid
	 */
	@TimeComplexity("O(1)")
	protected boolean checkKey(K key) throws IllegalArgumentException{
		try{
			return (comp.compare(key, key) == 0);	//see if key is valid
		}catch (ClassCastException e){
			throw new IllegalArgumentException("Key is Incompatible");
		}	
	}
	
}
