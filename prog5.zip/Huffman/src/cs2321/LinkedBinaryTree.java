package cs2321;
import java.util.Iterator;

import net.datastructures.*;
	

public class LinkedBinaryTree<E> implements BinaryTree<E>{
	
	//Node Class
	public class Node<E> implements Position<E>{
		//Instance Variables
		private E element;
		private Node<E> parent;
		private Node<E> left;
		private Node<E> right;
		
		// node constructor
		public Node (E element, Node<E> parent, Node<E> left, Node<E> right){
			this.element = element;
			this.parent =  parent;
			this.left = left;
			this.right = right;
		}

		@Override
		public E getElement() throws IllegalStateException {
			if (element == null)
				throw new IllegalStateException("Position invalid");
			return element;
		}
		
		//Getters
		public Node<E> getLeft() {
			return left;
		}
		public Node<E> getRight() {
			return right;
		}
		public Node<E> getParent() {
			return parent;
		}
		//Setters
		public void setElement(E element) {
			this.element = element;
		}
		public void setLeft(Node<E> left) {
			this.left = left;
		}
		public void setRight(Node<E> right) {
			this.right = right;
		}
		public void setParent(Node<E> parent) {
			this.parent = parent;
		}

	}
	
	Node<E> root;
	private int size = 0;

	//constructor
	public LinkedBinaryTree() { 
	}

	@Override
	public Position<E> root() {
		return root;
	}

	@Override
	public Position<E> parent(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		if (node.getParent() == null)
			return null;
		return node.getParent();
	}

	@Override
	public Iterable<Position<E>> children(Position<E> p) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int numChildren(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		int num = 2;
		if (node.getLeft() == null)
			num = num-1;
		if (node.getRight() == null)
			num = num-1;
		return num;
	}

	@Override
	public boolean isInternal(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		boolean in = true;
		if (node.getLeft() == null && node.getRight() == null)
			in  = false;
		return in;
	}

	@Override
	public boolean isExternal(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		boolean ext = false;
		if (node.getLeft() == null && node.getRight() == null)
			ext = true;
		return ext;
	}

	@Override
	public boolean isRoot(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		if (node.getParent() == null)
			return true;
		return false;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		if (size == 0)
			return true;
		return false;
	}

	@Override
	public Iterator<E> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable<Position<E>> positions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Position<E> left(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		return node.getLeft();
	}

	@Override
	public Position<E> right(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		return node.getRight();
	}

	@Override
	public Position<E> sibling(Position<E> p) throws IllegalArgumentException {
		Node<E> node = check(p);
		if(node.getParent().getRight() == node)
			return node.getParent().getLeft();
		return node.getParent().getRight();
	}
	
	/* creates a root for an empty tree, storing e as element, and returns the 
	 * position of that root. An error occurs if tree is not empty. 
	 */
	public Position<E> addRoot(E e) throws IllegalStateException {
		if (size > 0)
			throw new IllegalStateException("A root already exists");
		root = new Node<E>(e,null,null,null);
		size = 1;
		return root;
	}
	
	/* creates a new left child of Position p storing element e, return the left child's position.
	 * If p has a left child already, throw exception IllegalArgumentExeption. 
	 */
	public Position<E> addLeft(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = check(p);
		if (node.getLeft() != null)
			throw new IllegalArgumentException("Left child already exists");
		Node<E> left = new Node<E>(e,node,null,null);
		node.setLeft(left);
		size++;
		return left;
	}

	/* creates a new right child of Position p storing element e, return the right child's position.
	 * If p has a right child already, throw exception IllegalArgumentExeption. 
	 */
	public Position<E> addRight(Position<E> p, E e) throws IllegalArgumentException {
		Node<E> node = check(p);
		if (node.getRight() != null)
			throw new IllegalArgumentException("Right child already exists");
		Node<E> right = new Node<E>(e,node,null,null);
		node.setRight(right);
		size++;
		return right;
	}
	
	/* Attach trees t1 and t2 as left and right subtrees of external Position. 
	 * if p is not external, throw IllegalArgumentExeption.
	 */
	public void attach(Position<E> p, LinkedBinaryTree<E> t1, LinkedBinaryTree<E> t2)
			throws IllegalArgumentException {
		Node<E> node = check(p);
		if(isInternal(p))
			throw new IllegalArgumentException("Chidlren already exist for node");
		size = size + t1.size + t2.size;
		if (!t1.isEmpty()){
			t1.root.setParent(node);
			node.setLeft(t1.root);
			t1.root = null;
			t1.size = 0;
		}
		if (!t2.isEmpty()){
			t2.root.setParent(node);
			node.setRight(t2.root);
			t2.root = null;
			t2.size = 0;
		}
	}
	private Node<E> check(Position<E> p) throws IllegalArgumentException {
		if (!(p instanceof Node))
			throw new IllegalArgumentException("Invalid Node");
		Node<E> node = (Node<E>) p;
		if (node.getParent()== node)
			throw new IllegalArgumentException("Node is no longer in the tree");
		return node;
	}
	
	public static void main(String [ ] args) {
		LinkedBinaryTree<Integer> t1 = new LinkedBinaryTree<>();
		LinkedBinaryTree<Integer> t2 = new LinkedBinaryTree<>();
		LinkedBinaryTree<Integer> t3 = new LinkedBinaryTree<>();
		t1.addRoot(1);
		t1.addLeft(t1.root, 2);
		t1.addLeft(t1.root.left, 3);
		t2.addRoot(1);
		t2.addRight(t2.root, 2);
		t3.addRoot(2);
		t3.attach(t3.root, t1, t2);
		t3.left(t3.root);
		
		
	}
}
