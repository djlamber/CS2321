package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an Unordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Daniel Lambert
 */

public class UnorderedPQ<K,V> extends AbstractPriorityQueue<K,V> implements PriorityQueue<K,V> {
	private PositionalList<Entry<K,V>> list = new DoublyLinkedList<>();	//Priority queue entry collection

	//Constructors
	public UnorderedPQ() {	// Creates an empty PQ based on original key order
		super();
	}
	
	public UnorderedPQ(Comparator<K> c) {	//Creates a empty PQ using the comparator to order keys
		super(c);
	}
	

	/*
	 * Returns the size of the queue
	 * 
	 * @return the size of the queue
	 */
	@TimeComplexity("O(1)")
	public int size() {	//Returns size of queue
		return list.size();
	}

	/*
	 * Returns if the queue is empty
	 * 
	 * @return true if the queue is empty else returns false
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {	
		if (list.first() == null)
			return true;
		else
			return false;
	}

	/*
	 * Check and inserts a new Entry into the queue
	 * 
	 * @return the newly added Entry
	 */
	@TimeComplexity("O(1)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);	//Checks if the key is valid
		Entry<K,V> newest = new PQEntry<>(key,value);
		list.addLast(newest);
		return newest;
	}

	/*
	 * Finds and returns the minimum
	 * 
	 * @return if the list is empty null, else the minimum entry
	 */
	@TimeComplexity("O(n)")
	public Entry<K, V> min() {	
		if (list.isEmpty())
			return null;
		return findMin().getElement();

	}

	/*
	 * Finds and removes the minimum entry
	 * 
	 * @return if the list is emtpy nul, the removed entry
	 */
	@TimeComplexity("O(n)")
	public Entry<K, V> removeMin() {	//Checks to see if the list is empty. If not removes the minimum element
		if (list.isEmpty())
			return null;
		return list.remove(findMin());
	}
	
	
	/*
	 * Finds and returns the minimum entry
	 * 
	 * @return the minimum entry
	 */
	@TimeComplexity("O(n)")
	public Position<Entry<K,V>> findMin(){
		Position<Entry<K, V>> min = list.first();
		for (Position<Entry<K,V>> walk:list.positions()){
			if (compare(walk.getElement(),min.getElement())<0){
				min = walk;
			}
		}
		return min;	
	}

	
	

}
