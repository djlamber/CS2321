package cs2321;

import java.util.Comparator;

import net.datastructures.*;
/**
 * A PriorityQueue based on an ordered Doubly Linked List. 
 * 
 * Course: CS2321 Section ALL
 * Assignment: #3
 * @author Daniel Lambert
 */

public class OrderedPQ<K,V> extends AbstractPriorityQueue<K,V> implements PriorityQueue<K,V> {
	private PositionalList<Entry<K,V>> list = new DoublyLinkedList<>();	//Priority queue entry collection
	
	//Constructors
	public OrderedPQ() {	//Created a PQ based on original key order
		super();
	}
	public OrderedPQ(Comparator<K> c) {	//Created a empty PQ using the given comparator to order keys
		super(c);
	}
	
	
	/*
	 * Returns the size of the queue
	 * 
	 * @return the size of the queue
	 */
	@TimeComplexity("O(1)")
	public int size() {	
		return list.size();
	}

	/*
	 * Returns if the queue is empty
	 * 
	 * @return true if the queue is empty else returns false
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {	
		if (list.first() == null)
			return true;
		else
			return false;
	}

	/*
	 * Inserts an entry into the queue 
	 * 
	 * @return the entry inserted
	 * 
	 * @throws IllegalArgumentException if the key isn't valid
	 */
	@TimeComplexity("O(n)")
	public Entry<K, V> insert(K key, V value) throws IllegalArgumentException {
		checkKey(key);	//Checks if the key is valid
		Entry<K,V> newest = new PQEntry<>(key,value);
		Position<Entry<K,V>>walk = list.last();	//walks backwards looking to see if there is a smaller key
		while (walk != null && compare(newest, walk.getElement())<0)
			walk = list.before(walk);
		if (walk == null)
			list.addFirst(newest);
		else
			list.addAfter(walk,newest);
		return newest;
	}

	/*
	 * Checks and returns the minimum element
	 * 
	 * @return if the list is empty returns null, else returns the minimum element
	 */
	@TimeComplexity("O(1)")
	public Entry<K, V> min() {	
		if (list.isEmpty())
			return null;
		return list.first().getElement();

	}

	/*
	 * Checks and removes the minimum element
	 * 
	 * @return if the list is empty returns null, else returns the removed element
	 */
	@TimeComplexity("O(1)")
	public Entry<K, V> removeMin() {
		if (list.isEmpty())
			return null;
		return list.remove(list.first());
	}

}
