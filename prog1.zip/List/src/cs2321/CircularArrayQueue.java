
/**
 * Implement Queue ADT using a fixed-length array in circular fashion 
 *
 * @author ruihong-adm
 * @param <E> - formal type 
 *
 */

/*
 * Daniel Lambert
 * Assignment 1
 * This class is used to create a CircularArrayQueue that acts as a queue with the elements stored in an array, circling around as a loop
 */
package cs2321;

import net.datastructures.Queue;

public class CircularArrayQueue<E> implements Queue<E> {
	// Instance variables
	private int size; // Size of the circularArrayQueue
	private E[] queue; // the array the queue is stored in
	private int front; // the index of the front of the queue
	private int back; // the index of the back of the queue

	// Constructor
	public CircularArrayQueue(int queueSize) {
		queue = (E[]) new Object[queueSize]; //safe cast
	}

	/*
	 * gets the size of the array and returns it
	 * 
	 * @return the size of the array
	 */
	@TimeComplexity("O(1)")
	public int size() {
		return size;
	}

	/*
	 * Checks to see if the size of the array is 0
	 * 
	 * @return a boolean if the array is empty or not
	 */
	@TimeComplexity("O(1)")
	public boolean isEmpty() {
		if (size == 0)
			return true;
		else
			return false;
	}

	/*
	 * enqueues the element into the array and moves the back to the next
	 * position
	 * 
	 * @throws IllegalStateException when the queue is full
	 */
	@TimeComplexity("O(1)")
	public void enqueue(E e) throws IllegalStateException {
		if (size() == queue.length)
			throw new IllegalStateException("Queue Full");
		queue[back] = e;
		back = (back + 1) % queue.length;
		size++;

	}

	/*
	 * finds the first element in the queue. If the queue is empty returns null
	 * 
	 * @return the first element at the beginning of the queue
	 */
	@TimeComplexity("O(1)")
	public E first() {
		if (isEmpty())
			return null;
		return queue[front];
	}

	/*
	 * dequeues the first element out of the array and returns it and makes the
	 * next position the first one. Returns null if array is empty
	 * 
	 * @return the first element is dequeued and the front is moved to the next
	 * element
	 */
	@TimeComplexity("O(1)")
	public E dequeue() {
		if (isEmpty())
			return null;
		E result = queue[front];
		queue[front] = null;
		front = (front + 1) % queue.length;
		size--;

		return result;
	}

	public static void main(String[] args) {
		CircularArrayQueue<String> Test = new CircularArrayQueue<>(12);
		for (int i = 0; i < 11; i++) {
			Test.enqueue("" + i);
		}
		for (int i = 0; i < 4; i++) {
			System.out.println("Dequeue: "+Test.dequeue());
			System.out.println("size: "+Test.size());
			System.out.println("First: "+Test.first());
		}
		for (int i = 0; i < 4; i++) {
			Test.enqueue("" + i);
		}
		for (int i = 0; i < 4; i++) {
			System.out.println("Dequeue: "+Test.dequeue());
			System.out.println("size: "+Test.size());
			System.out.println("first: "+Test.first());
		}

	}

}
